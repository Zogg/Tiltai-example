from nanomsg import Socket, PUSH, PULL, PUB, SUB, SUB_SUBSCRIBE, PAIR, SOL_SOCKET, SNDTIMEO, NanoMsgAPIError
from nanomsg import wrapper as nn_wrapper

import threading
import Queue
import socket

from logbook import Logger

log = Logger("{host} - {service}".format(host=socket.gethostname(), service="nanolink"))

def receiver(queue, addresses, stype):
  def worker():
    queue.put(socket.receive())
  return socket

def sender(queue, addresses, stype):
  return socket

def gate(type, queue=Queue.Queue(), network={}, governor=None):
  if type == 'out':
      socket = sender(queue, network['endpoints'], stype=network['type'])
      if governor:
        governor(socket=socket, socketupdater=update, endpoints=[ep.address for ep in socket.endpoints])
  elif type == 'in':
      socket = receiver(queue, network['endpoints'], stype=network['type'])
  elif type == 'utility':
      pass
  else:
      raise ValueError("No such gate type known.")
  
  return queue

def igate(queue=Queue.Queue(), network={}):
  return gate('in', queue, network)

def ogate(queue=Queue.Queue(), network={}):
  return gate('out', queue, network) 

def iogate(type, queuein=Queue.Queue(), queueout=Queue.Queue(), network={}):
  return (queuein, queueout)    

        
def pull(queue):
  return queue.get(block=True)

def push(message, queue):
  queue.put(message)
    
    
def update(socket, operational_address):
  pass
